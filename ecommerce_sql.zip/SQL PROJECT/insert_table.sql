INSERT INTO users (user_id, name, email) VALUES
(1, 'Rahul', 'rahul@gmail.com'),
(2, 'Neha', 'neha@gmail.com');

INSERT INTO categories (category_id, category_name) VALUES
(1, 'Electronics'),
(2, 'Clothing'),
(3, 'Books');

INSERT INTO products (product_id, product_name, price, stock, category_id) VALUES
(1, 'Laptop', 55000, 10, 1),
(2, 'Mobile Phone', 20000, 15, 1),
(3, 'T-Shirt', 800, 50, 2),
(4, 'SQL Book', 500, 30, 3);

INSERT INTO orders (order_id, user_id) VALUES
(1, 1),
(2, 2);

INSERT INTO order_items (order_item_id, order_id, product_id, quantity, price) VALUES
(1, 1, 1, 1, 55000),
(2, 1, 4, 2, 500),
(3, 2, 3, 1, 800);
