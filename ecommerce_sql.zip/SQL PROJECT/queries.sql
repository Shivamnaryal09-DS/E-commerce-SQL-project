
-- STEP 1: Get each product along with its category name
SELECT 
    p.product_name,        -- product name from products table
    c.category_name        -- category name from categories table
FROM products p
JOIN categories c
    ON p.category_id = c.category_id;   -- matching category_id
-- STEP 2: Find which user placed which order1
SELECT 
    u.name,                -- user name from users table
    o.order_id             -- order id from orders table
FROM users u
JOIN orders o
    ON u.user_id = o.user_id;   -- matching user_id

-- STEP 3: Show items present in each order
SELECT 
    oi.order_id,           -- order id
    oi.product_id,         -- product id
    oi.quantity            -- quantity ordered
FROM order_items oi;

-- STEP 4: Get product names for items in orders
SELECT 
    oi.order_id,           -- order id
    p.product_name,        -- product name
    oi.quantity     -- quantity ordered
FROM order_items oi
JOIN products p
    ON oi.product_id = p.product_id
JOIN orders o
	ON o.order_id=oi.order_id;
-- STEP 5: Complete order details with user, product and category
SELECT 
    u.name,                -- customer name
    o.order_id,            -- order id
    p.product_name,        -- product name
    c.category_name,       -- category name
    oi.quantity             -- quantity ordered
FROM users u
JOIN orders o 
    ON u.user_id = o.user_id          -- users → orders
JOIN order_items oi 
    ON o.order_id = oi.order_id       -- orders → order_items
JOIN products p 
    ON oi.product_id = p.product_id   -- order_items → products
JOIN categories c 
    ON p.category_id = c.category_id; -- products → categories

