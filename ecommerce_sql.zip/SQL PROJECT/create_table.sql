create database ecommerce;
 use ecommerce;
 
-- Stores customer information
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT, -- unique user id
    name VARCHAR(100),                       -- customer name
    email VARCHAR(100) UNIQUE,               -- unique email
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Stores product categories like Electronics, Clothing, etc.
CREATE TABLE categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT, -- unique category id
    category_name VARCHAR(100) NOT NULL          -- category name
);


-- Stores product details
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT, -- unique product id
    product_name VARCHAR(100) NOT NULL,         -- product name
    price DECIMAL(10,2) NOT NULL,                -- product price
    stock INT DEFAULT 0,                         -- available quantity
    category_id INT,                             -- category reference

    -- foreign key linking product to category
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);


-- Stores order information (who ordered and when)
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT, -- unique order id
    user_id INT,                             -- customer who placed order
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- foreign key linking order to user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);


-- Stores products inside each order
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT, -- unique row id
    order_id INT,                                 -- order reference
    product_id INT,                               -- product reference
    quantity INT NOT NULL,                        -- quantity ordered
    price DECIMAL(10,2) NOT NULL,                  -- price at order time

    -- foreign key linking to orders table
    FOREIGN KEY (order_id) REFERENCES orders(order_id),

    -- foreign key linking to products table
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
